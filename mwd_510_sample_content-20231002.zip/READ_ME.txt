You can use the dummy pages and images in these folders to populate your website with content
